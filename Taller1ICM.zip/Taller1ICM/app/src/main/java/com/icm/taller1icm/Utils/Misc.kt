package com.icm.taller1icm.Utils

import android.content.Context
import java.io.IOException

class Misc {
    companion object{ //TODO LO QUE ESTÁ ACÁ ES GLOBAL PARA TODA LA APLICACIÓN
        fun loadJSONFromAsset(context: Context, fileName: String): String? {
            return try {
                val inputStream = context.assets.open(fileName)
                val size = inputStream.available()
                val buffer = ByteArray(size)
                inputStream.read(buffer)
                inputStream.close()
                String(buffer, Charsets.UTF_8)
            } catch (ex: IOException) {
                ex.printStackTrace()
                null
            }
        }
    }
}