package com.icm.taller1icm.LogicaActivities

import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isVisible
import com.icm.taller1icm.R
import com.icm.taller1icm.Utils.Misc
import com.icm.taller1icm.databinding.ActivityPantalla2Binding
import org.json.JSONObject
import java.io.IOException
import java.io.InputStream

class Pantalla2 : AppCompatActivity(), AdapterView.OnItemSelectedListener{
    private lateinit var binding: ActivityPantalla2Binding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityPantalla2Binding.inflate(layoutInflater)
        setContentView(binding.root)

        val category = intent.getStringExtra("CATEGORY") ?: "Todos"
        val destinos = loadJSONFromAsset().filter {
            it.categoria == category || category == "Todos"
        }
        displayDestinos(destinos)

    }
    private fun displayDestinos(destinos: List<Destino>) {
        val listView: ListView = findViewById(R.id.listViewDestinos)
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, destinos.map {
            it.nombre
        }
    })
        listView.adapter = adapter
    }

    private fun cargarDestinos() {
        val arreglo = arrayListOf<String>()
        val destinos = arrayListOf<String>()
        val json = JSONObject(Misc.loadJSONFromAsset(this, "destinos.json"))
        val destinosJson = json.getJSONArray("destinos")

        for (i in 0 until destinosJson.length()) {
            val jsonObject = destinosJson.getJSONObject(i)
            arreglo.add(jsonObject.getString("nombre"))
        }

        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, arreglo)
        findViewById<ListView>(R.id.lista).adapter = adapter
        binding.lista.setOnItemClickListener(object : AdapterView.OnItemClickListener {
            override fun onItemClick(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {

                Toast.makeText(baseContext, capitales[position], Toast.LENGTH_SHORT).show()

            }
        }
    }
}