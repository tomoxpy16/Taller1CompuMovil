package com.icm.taller1icm.LogicaActivities

import android.os.Bundle
import android.content.Context
import android.content.Intent
import android.util.Log
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.icm.taller1icm.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.spinner.onItemSelectedListener = this

        findViewById<Button>(R.id.btnExplorarDestinos).setOnClickListener {
            lanzarPantalla2()
        }
    }

    private fun lanzarPantalla2() {
        val selectedCategory = findViewById<Spinner>(R.id.spinnerCategorias).selectedItem.toString()
        val intent = Intent(this, Pantalla2::class.java).apply {
            putExtra("CATEGORY", selectedCategory)
        }
        startActivity(intent)
    }
}