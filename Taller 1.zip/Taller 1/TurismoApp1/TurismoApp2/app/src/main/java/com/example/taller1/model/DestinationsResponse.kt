package com.example.taller1.model

data class DestinationsResponse(val destinos: List<Destination>)
